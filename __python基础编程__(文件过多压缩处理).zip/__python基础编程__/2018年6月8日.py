#2018年６月８日２.py
sn = 0
for x in range(1,1000001):
	if x % 2 != 0:
		sn+=1/(2*x-1)

	else:
		sn-=1/(2*x-1)
else:
	print(sn*4)