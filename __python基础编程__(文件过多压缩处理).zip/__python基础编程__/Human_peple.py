#有两个人：
#1.姓名：张三  年龄：35岁
#2.姓名：李四  年龄：8岁
#行为：
#1.教别人东西 teacher
#2.工作赚钱 work
#3.借钱 borrow
#用程序描述如下事情：
'''张三 教 李四 学 python
李四 教 张三 学 滑冰
张三 上班 赚了 1000元
李四 向 张三 借了 200元钱
显示李四的全部信息
显示张三的全部信息'''
class Human:
    def __init__(self,name,age):
        self.name = name #姓名
        self.age = age  #年龄
        self.money = 0 #设置默认参数零元
        self.skill = [] #设置空列表
    def teacher(self,other,skl):
        other.skill.append(skl)#other得到了技能
        print(self.name,'正在教',other.name,'学',skl)
    def work(self,money):#money函数
        self.money += money #原来的钱+现在赚的钱
        print(self.name,'上班赚了',money,'元钱')
    def borrow(self,other,money):
        '''先判断对方有没有足够的钱,成功返回True/False'''
        if other.money > money:
            other.money -= money
            self.money += money
            print(other.name,'借给了',self.name,money,'元钱')  #成功执行的语句
            return True
        print('对方没有足够的钱，无法借给你')
        return False   #借钱失败
    def show_info(self):
        print(self.age,'岁的',self.name,'有技能',self.skill,'钱包内的钱数是',self.money)
zhang3 = Human('张三',35)
lisi = Human('李四',8)
zhang3.teacher(lisi,'python')
lisi.teacher(zhang3,'滑冰')
zhang3.work(1000) #赋值给work
'''李四向张三借钱'''
lisi.borrow(zhang3,200) #借钱操作
zhang3.show_info()
lisi.show_info()
