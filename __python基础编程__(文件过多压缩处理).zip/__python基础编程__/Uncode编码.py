#Uncode编码
s=input('请输入一个字符串：')
i=0
encode_max =ord(s[0])
while i < len(s):
	if ord(s[i]) > encode_max:
		encode_max=ord(s[i])
	print('这个字符串的最大编码值是:',encode_max)
	print('编码值是：',chr(encode_max))
	i+=1