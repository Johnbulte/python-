class Mylist:
    def __init__(self,iterable=()):
        self.data=[x for x in iterable]
    def append(self,v):
        self.data.append(v)
    def __repr__(self):
        return 'Mylist(%r)'%self.data
    def __iter__(self):
        return MyIterator(self.data)
class MyIterator:
    def __init__(self,lst):
        self.data = lst
        self.index=0
    def __next__(self):
        if self.index>=len(self.data):
            raise StopIteration
        r = self.data[self.index]
        self.index+=1
        return r
L=Mylist('ABCD')
print(L)
L.append('E')
print(L)
