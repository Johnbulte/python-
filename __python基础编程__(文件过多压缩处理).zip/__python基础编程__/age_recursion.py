#age_recursion.py
#设定一个递归函数
#已知第一个人是十岁
#第二个比第一个大两岁
def age_int(n):  
      if n == 1: #第一个人 
            return 10  
      else:  
            return age_int(n-1)+2  
  
print('第五个人的岁数是%d岁' % age_int(5))






