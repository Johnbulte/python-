
wegiht=int(input('请输入体重：'))
height=int(input('请输入身高：'))
height=height*0.01#将cm转成m
bmi=wegiht/height**2


if bmi<18.5:
	print('您太瘦了，请多吃点')
elif 18.5<=bmi<=24:
	print('体重正常，继续保持哦')
else:
	print('啊呀太胖了，该减肥了')
