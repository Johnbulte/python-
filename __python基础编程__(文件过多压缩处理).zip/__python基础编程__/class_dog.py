class Dog:
    pass
dog1 = Dog()
print(dog1.__dict__)#空字典
dog1.color = '白色'#color颜色
print(dog1.__dict__)#color是键白色是值
