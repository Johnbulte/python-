#class_student_info.py
#class Student:
    #'''此处自己实现'''
#学生信息有：
#姓名，年龄，成绩
#将这些学生对象存于列表中，可以任意添加和删除学生信息
#1.打印学生的个数
#2.打印出所有学生的平均成绩
#3.打印出所有学生的平均年龄
#'''建议用类变量存储学生的个数'''
class Student:
    count = 0
    def __init__(self,n,a,s):
        self.name = n
        self.age = a
        self.score = s
        self.__class__.count += 1
L =[]  #空列表
L.append(Student('小张',20,100))   #append追加列表内容
L.append(Student('小李',27,105))
L.append(Student('小三',21,98))
L.append(Student('小五',17,99))
del L[1]  #删除列表中第一个元素
print(L)
print('当前有%d个学生'%Student.count)
scores = 0
for s in L:
    scores += s.score
print('平均成绩是:',scores/Student.count)
ages = sum((s.age for s in L))
print('平均成绩是:',ages/Student.count)
