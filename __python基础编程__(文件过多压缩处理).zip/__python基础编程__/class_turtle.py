#class_turtle.py
import time
class Turtle:
    #python中的类名约定以大写字母开头
    #特征的描述称为属性，在代码层面来看其实就是变量
    color = 'green'
    weight = 10
    legs = 4
    shell = True
    mouth = '大嘴'
    #方法实际就是函数，通过调用这些函数来完成某些动作
    def climb(self):
        print('我正在努力的向前爬........')
        time.sleep(1.5)
    def run(self):
        print('我正在飞快的向前跑')
        time.sleep(1)
    def bite(self):
        print('我咬死你，咬死你')
        time.sleep(2)
    def eat(self):
        print('我要开始吃东西啦')
        time.sleep(5)
    def sleep(self):
        print('吃饱了开始睡觉，晚安')
        time.sleep(10)
tt = Turtle()
tt.climb()
tt.run()
tt.bite()
tt.eat()
tt.sleep()
print('程序结束')
