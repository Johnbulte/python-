#class_variable2.py
class Human:
    total_count = 0
    def __init__(self,n):
        self.name = n
        '''如果一个对象诞生，则这个对象做+1操作'''
        self.__class__.total_count += 1
print('当前有%d个Human的实例对象' % Human.total_count)
h1 =Human('小李')
print('当前有%d个Human的实例对象' % Human.total_count)
h2 =Human('小张')
