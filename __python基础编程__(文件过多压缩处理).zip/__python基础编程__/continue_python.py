#continue_python.py

start = int(input('请输入一个整数:'))

stop = int(input('请输入第二个整数:'))

for x in range(start,stop,2):
	if x % 2 == 0:
		continue
	print(x)