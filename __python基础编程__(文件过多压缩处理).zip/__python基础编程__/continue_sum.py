#continue_sum.py
s=0
for x in range(1,100):
	if x % 5 == 0 or x % 7 == 0 or x % 11 == 0 :
		continue
	print(x)
	s += x
print('以上所有数的和是:',s)
