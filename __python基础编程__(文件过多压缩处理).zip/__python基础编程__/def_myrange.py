#def_myrange.py
def myrange(start,stop=0,step=1):
    if stop is None:
        stop = start
        start = 0
    if step > 0:
        while start < stop:
            yield start
            start += step
    elif step <0:
        while start > stop:
            yield start
            start += step
print(sum(x**2 for x in myrange(1,11) if x % 2))
