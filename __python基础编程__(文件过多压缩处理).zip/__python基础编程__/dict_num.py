#dict_num.py
d ={}
while True:
	n=input('请输入单词：')
	if n =="":
		break
	s=input('请输入解释:')
	
	d[n]=s
scc = input('请输入您想要查询的单词:')

print('%s单词的解释为:%s'%(scc,d[scc]))