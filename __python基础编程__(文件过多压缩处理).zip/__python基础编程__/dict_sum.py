#dict_sum.py
s = input('请输入字符串:')
#方法１，去除重复的
#
L = []#此列表统计出现过的字符

for ch in s:
	if ch not in L:
		L.append(ch)
print('去重之后的列表:',L)
for ch in L:
	print(ch,":",s.count(ch),'次')
