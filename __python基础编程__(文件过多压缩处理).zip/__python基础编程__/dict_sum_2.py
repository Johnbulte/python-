#dict_sum_2.py

d = {}
#定义一个空字符
s = input('请输入字符串:')
for ch in s:
	if ch not in d :
		#ch第一次出现
		d[ch]=1 #添加到字典中
	else:   #ch不是第一次出现了
		d[ch]+=1
	print(d)
for ch in d:
	print(ch,':',s.count(ch),'次')