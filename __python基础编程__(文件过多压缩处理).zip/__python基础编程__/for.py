#for.py

s = 'ABCDE'

for ch in s:
	print('ch-->>',ch)
#遍历关系，每个执行一次