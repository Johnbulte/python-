#for3
s = 0
for x in range(1,100,2):
	s += x
else:
	print('和是：',s)
