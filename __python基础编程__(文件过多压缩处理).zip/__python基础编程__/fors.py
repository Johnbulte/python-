#for.py
n = int(input('请输入一个整数:'))
for line in range(n):
	for i in range(line+1,line+1+n):
		print('%02d'% i,end=" ")
	print()

