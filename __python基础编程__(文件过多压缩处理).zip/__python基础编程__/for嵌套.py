#for嵌套

for x in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    for y in '1234567890':
    	for z in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    		for j in '1234567890':
        		print(x+y+z+j)