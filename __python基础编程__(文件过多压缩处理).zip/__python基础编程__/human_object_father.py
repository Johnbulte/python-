class Human:
    pass
class Student(Human):
    pass
class Teacher(Human):
    pass
print(Student.__base__ is Human)  #True
