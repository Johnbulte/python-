#input_max_min_sum.py
L = list()
while True:
	n = int(input('请输入整数：'))
	if n < 0:
		break
	L.append(n)
print('您输入的是：',L)
print('输入的和是：',sum(L))
L.sort(reverse=True)
print('最大数是：',L[0])
print('第二大数是：',L[0])
L.pop()
print('最终是:',L)