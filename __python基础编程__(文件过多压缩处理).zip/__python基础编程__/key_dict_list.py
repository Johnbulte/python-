#key_dict_list.py

No=[1001,1002,1005,1008]
Names = ['Tom','Jerry','Spike','Tyke']
d = {No[i]:Names[i] for i in range(len(No))}
print(d)