#list_del.py

L=[3,5]

print('源列表的id是:',id(L))

L[1:1] = [4]

print('插入后：',L,'id是:',id(L))

L[0:0] = [1,2]

L[5:] = [6]

print('最终是：',L)

L=L[::-1]

print('翻转后是：',L)