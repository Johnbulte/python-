#list_dict_key.py

L = ['tarena','china','beijing']

D={x:len(x) for x in(L)}
print(D)