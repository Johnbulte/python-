#list_ji_.py
L=[x for x in range(1,100,2)]
print(L)