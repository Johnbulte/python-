#list_pass.py
L=[]
while True:	
	a=input('请您输入内容：')
	if not a:
		break
	L+=[a]
print('绑定的列表是:',L)
print('您输入的行数是:',len(L))
ch = 0
for a in L:
	ch += len(a)
print('您输入的是%d'%ch)