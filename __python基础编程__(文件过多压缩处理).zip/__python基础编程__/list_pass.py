#list_pass.py
a = input('请输入第一个数:')
b = input('请输入第二个数：')
c = input('请输入第三个数：')
l=[a,b,c]
print(l)