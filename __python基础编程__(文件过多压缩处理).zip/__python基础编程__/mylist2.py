#mylist_2.py
#此示例示意复合赋值算数运算符的重载
class Mylist:
    def __init__(self,iterable=()):
        self.data = [x for x in iterable]
    def __repr__(self):
        return 'Mylist(%r)'%self.data
    def __add__(self,rhs):
        print('__add__')
        return Mylist(self.data+rhs.data)
L1 = Mylist([1,2,3,4,5])
L2 = Mylist([4,5,6,7])
L1 += L2
print('L1=',L1)
print(id(L1))
l1 = list([1,2,3,4,5])
l2 = list([4,5,6,7])
l1 += l2
print('l1=',l1)
print(id(l1))
