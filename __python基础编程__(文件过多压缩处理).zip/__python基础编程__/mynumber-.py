#mynumber.py
'''此示例示意自定义的类通过运算符重载实现运算符操作'''
class Mynumber:
    def __init__(self,v):
        self.data = v
    def __repr__(self):
        return 'Mynumber(%d)'%self.data
    def __sub__(self,other):
        '''实现加法操作，生成一个新的对象并返回给调用者'''
        return self.data - other.data
n1 = Mynumber(100)
n2 = Mynumber(200)
#n3 = n1 + n2
#print(n3)   #错
#n3 = n1.add(n2)+
n3 = n1.__sub__(n2)
print(n1,'-',n2,'=',n3)
