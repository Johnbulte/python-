#! /usr/bin/python3
#自己的实验性操作

username=66
passwd=123456
l=66
p=123456
l=int(input('请输入用户名：'))
if l==66:
	print('用户名正确')
else:
	print('用户名不正确')
p=int(input('请输入密码：'))
if p ==123456:
	print('密码正确')
else:
	print('密码错误')