#print_list.py
L =[[3,5,8],10,[[13,14],15,18],20]
L1 = []
def print_list(lst):
	for x in lst:
		if type(x) is list:
			print_list(x)
		elif type(x) is int:
			L1.append(x)
	return L1
print(print_list(L))
print('和是:',sum(L1))