#property.py
'''此示例示意特性属性的用法'''
class Student:
    def __init__(self,score):
        self.__score = score
    def get_score(self):
        return self.__score
    def set_score(self,s):
        if 0 <= s <= 100:
            self.__score = s
        else:
            raise ValueError
    score = property(get_score,set_score)
s = Student(59)
print(s.score)
s.score = 97
print(s.score)
