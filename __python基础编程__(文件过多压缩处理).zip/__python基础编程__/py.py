#py.py
i = 6
for x in range(1,i):
	print('x = ',x,'i = ',i)
	i-=1