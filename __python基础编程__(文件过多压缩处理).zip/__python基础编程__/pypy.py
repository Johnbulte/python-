x=1
while x<=20:
    print(x,end=' ')
    if x % 5==0:
        print()
    x+=1
print()