﻿<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003" DefaultTargets="Build">
  <PropertyGroup>
    <Configuration Condition=" '$(Configuration)' == '' ">Debug</Configuration>
    <SchemaVersion>2.0</SchemaVersion>
    <ProjectGuid>{7452ea7b-46ae-4866-b275-8390bfcd4465}</ProjectGuid>
    <ProjectHome />
    <StartupFile>2018年6月8日.py</StartupFile>
    <SearchPath />
    <WorkingDirectory>.</WorkingDirectory>
    <OutputPath>.</OutputPath>
    <ProjectTypeGuids>{888888a0-9f3d-457c-b088-3a5042f75d52}</ProjectTypeGuids>
    <LaunchProvider>Standard Python launcher</LaunchProvider>
    <InterpreterId />
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)' == 'Debug'" />
  <PropertyGroup Condition="'$(Configuration)' == 'Release'" />
  <PropertyGroup>
    <VisualStudioVersion Condition=" '$(VisualStudioVersion)' == '' ">10.0</VisualStudioVersion>
  </PropertyGroup>
  <ItemGroup>
    <Compile Include="2018年6月8日.py" />
    <Compile Include="age_recursion.py" />
    <Compile Include="bmi体重换算表.py" />
    <Compile Include="continue_python.py" />
    <Compile Include="continue_sum.py" />
    <Compile Include="dict.py" />
    <Compile Include="dict_num.py" />
    <Compile Include="dict_sum.py" />
    <Compile Include="dict_sum_2.py" />
    <Compile Include="for%255.py" />
    <Compile Include="for.py" />
    <Compile Include="for2.py" />
    <Compile Include="for3.py" />
    <Compile Include="fors.py" />
    <Compile Include="for嵌套.py" />
    <Compile Include="input_max_min_sum.py" />
    <Compile Include="key_dict_list.py" />
    <Compile Include="list_del.py" />
    <Compile Include="list_dict_key.py" />
    <Compile Include="list_ji_.py" />
    <Compile Include="list_num.py" />
    <Compile Include="list_pass.py" />
    <Compile Include="passwd.py" />
    <Compile Include="print_list.py" />
    <Compile Include="py.py" />
    <Compile Include="pypy.py" />
    <Compile Include="range.py" />
    <Compile Include="range3.py" />
    <Compile Include="score.py" />
    <Compile Include="score2.py" />
    <Compile Include="score_print.py" />
    <Compile Include="seasons_num_key.py" />
    <Compile Include="space.py" />
    <Compile Include="student_login_power_get.py" />
    <Compile Include="sum_min_max.py" />
    <Compile Include="sushu.py" />
    <Compile Include="taxi.py" />
    <Compile Include="time.py" />
    <Compile Include="type_1_9.py" />
    <Compile Include="Uncode编码.py" />
    <Compile Include="year.py" />
    <Compile Include="year测试.py" />
    <Compile Include="三单引号.py" />
    <Compile Include="三角形.py" />
    <Compile Include="三角形２.py" />
    <Compile Include="判断一个数是否为正负或零.py" />
    <Compile Include="判断字母是否出现.py" />
    <Compile Include="判断输入一个数是不是在０～１００之间.py" />
    <Compile Include="占位符的用法.py" />
    <Compile Include="占位符练习.py" />
    <Compile Include="去空格.py" />
    <Compile Include="变量输出.py" />
    <Compile Include="合同.py" />
    <Compile Include="回文判断.py" />
    <Compile Include="圣诞树.py" />
    <Compile Include="在终端打印图形.py" />
    <Compile Include="多项式的值.py" />
    <Compile Include="字符串的打印处理.py" />
    <Compile Include="居中对齐.py" />
    <Compile Include="循环求和.py" />
    <Compile Include="循环语句的练习.py" />
    <Compile Include="循环语句的练习2.py" />
    <Compile Include="思考能否以最长字符串进行右对齐显示.py" />
    <Compile Include="打印1-20的整数.py" />
    <Compile Include="打印指定宽度的正方形.py" />
    <Compile Include="换行打印字符.py" />
    <Compile Include="整数求和.py" />
    <Compile Include="时间计数.py" />
    <Compile Include="月份练习.py" />
    <Compile Include="格式化字符串.py" />
    <Compile Include="步长的使用方法.py" />
    <Compile Include="求100以内求于.py" />
    <Compile Include="满100元减20元.py" />
    <Compile Include="猜拳游戏.py" />
    <Compile Include="用while打印10-1的整数.py" />
    <Compile Include="用户登录.py" />
    <Compile Include="练习.py" />
    <Compile Include="终端打印三角形.py" />
    <Compile Include="绝对值.py" />
    <Compile Include="编码.py" />
    <Compile Include="编码2.py" />
    <Compile Include="计量.py" />
    <Compile Include="课余实验：绝对值.py" />
    <Compile Include="输入一个数字打印相应图形.py" />
  </ItemGroup>
  <Import Project="$(MSBuildExtensionsPath32)\Microsoft\VisualStudio\v$(VisualStudioVersion)\Python Tools\Microsoft.PythonTools.targets" />
</Project>