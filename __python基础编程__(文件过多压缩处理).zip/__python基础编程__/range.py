#range.py
for x in range(3,6):
	print(x)
