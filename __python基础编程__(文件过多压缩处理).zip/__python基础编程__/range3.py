#range.py
for x in range(4,0):
	print(x)
print('x绑定',x)
#报错