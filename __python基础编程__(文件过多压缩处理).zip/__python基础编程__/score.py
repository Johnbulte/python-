
socore1=int(input('输入成绩:'))
socore2=int(input('输入成绩:'))
socore3=int(input('输入成绩:'))

if socore1<socore2<socore3 or socore1<socore3<socore2:
	print('最小数为',socore1)
elif socore2<socore1<socore3 or socore2<socore3<socore1:
	print('最小数为',socore2)
else:
	print('最小数为',socore3)

print((socore1+socore2+socore3)/3,'分')

