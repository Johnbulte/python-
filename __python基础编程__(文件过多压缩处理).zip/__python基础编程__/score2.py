
socore1=int(input('输入成绩:'))
socore2=int(input('输入成绩:'))
socore3=int(input('输入成绩:'))

print('最高分',max(socore1,socore2,socore3))#  
print('最低分',min(socore1,socore2,socore3))
l=[socore1,socore2,socore3]
print('平均分',int(sum(l)/3))
