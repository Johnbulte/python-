#score_print.py
l=[]#列表

while True:#while循环
    d={}#字典(空)
    name=input('请输入姓名：')
    if name =='':#判断是否为空字符
        break
    age=input('请输入年龄：')
    score=input('请输入成绩：')
    d['name']=name
    d['age']=age
    d['score']=score
    l.append(d)

    

print(l)

print('+----------------------------------+')
print('|   name    |    age     |  score  |')
print('+----------------------------------+')
for x in l:
    #print(x)
    print('|'+x['name'].center(11-len(x['name']))+'|'+x['age'].center(14-len(x['age']))+'|'+x['score'].center(11-(len(x['score'])))+'|')
print('+----------------------------------+')
