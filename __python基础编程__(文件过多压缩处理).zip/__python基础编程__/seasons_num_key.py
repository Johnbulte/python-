#seasons_num_key.py
#先生成一个字典
d={1:'春季有1,2,3月',2:'夏季有4,5,6月',3:'秋季有7,8,9月',4:'冬季有10,11,12月'}
num = int(input('请输入一个整数:'))
if num in d:
	print(d[num])
else:
	print('信息不存在！')
