#slots.py
#此示例示意__slots__属性的作用和用法
class Student:
    #此列表让student创建的对象只能用name和age属性
    __slots__ = ['name','age']  #不能有列表外的属性
    def __init__(self,name,age):
        self.name = name
        self.age = age
s1 = Student('Tarana',15)
print(s1.age)  #15
#s1.Age = 16   //主动报错，不允许添加__slots__列表以外的属性
s1.age = 16

print(s1.age) #?
