#计算字符串的空格数

a = input('请输入一个字符串:')#字符串赋值给a
conut = 0
for ch in a:
	if ch == ' ':
		conut+=1
	print('CH----->>>',ch)	
else:
	print('空格的个数是:',conut)

conut_a = 0
for ch in a:
	if ch == 's':
		conut_a+=1
	print(ch)	
else:
	print('s的个数是:',conut_a)