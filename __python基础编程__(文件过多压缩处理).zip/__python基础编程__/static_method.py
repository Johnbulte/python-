#static_method.py
class A:
    @staticmethod
    def myadd(x,y):
        return x+y
print(A.myadd(100,200))
a = A()
print(a.myadd(300,400))
