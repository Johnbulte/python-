class Student:
    def __init__(self,name,age,score=0):
        self.name=name
        self.age=age
        self.score=score
    def set_score(self,score):
        if 0<=score<=100:
            self.score=score
        else:
            raise ValueError('值不在相应范围')

    def show_info(self):
        print(self.name,'今年',self.age,'岁','成绩是',self.score)


s1=Student('小魏',17,59)
s1.set_score(68)
s1.show_info()
