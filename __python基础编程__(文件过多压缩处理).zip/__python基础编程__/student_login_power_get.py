#student_login_power_get.py
# -*- coding: UTF-8 -*-
import time

stutent_list = []

def add_card():
    name = input('请输入姓名：')
    age = input('请输入年龄：')
    qq = input('请输入QQ：')
    mail = input('请输入邮箱：')
    dict = {}
    dict['name'] = name
    dict['age'] = age
    dict['qq'] = qq
    dict['mail'] = mail
    stutent_list.append(dict)

def show_all():
    global stutent_list
    table_head()
    for dict in stutent_list:
        print('-' * 32)
        print('|\t%s\t|\t%s\t|\t%s\t|\t%s\t|' % (dict['name'], dict['age'], dict['qq'], dict['mail']))



def search_card():
    global stutent_list
    name = input('请输入查找学生的姓名：')
    for dict in stutent_list:
        if dict['name'] == name:
            table_head()
            print('-' * 32)
            print('|\t%s\t|\t%s\t|\t%s\t|\t%s\t|' % (dict['name'], dict['age'], dict['qq'], dict['mail']))
            print('您可以执行操作：1.删除\t2.修改\t3.返回上一级')
            deal_card(dict)
            break
    else:
        print('查无此人！！！')


def table_head():
    print('_' * 32)
    print('| 姓名\t|\t年龄\t|\tQQ\t|\t邮箱\t|')


def deal_card(dict):
    order = input('请输入命令:')
    while True:
        if order == '1':
            delete_card(dict)
            break
        elif order == '2':
            modify_card(dict)
            break
        elif order == '3':
            break
        else:
            print('输入有误,命令无效')

def delete_card(dict):
    print('执行命令，删除数据')
    stutent_list.remove(dict)
    print('...正在删除，请等待...')
    turnTime()
    print('删除成功，返回主界面')


def modify_card(dict):
    print('执行命令，修改数据')
    dict['name'] = input('请输入姓名：')
    dict['age'] = input('请输入年龄：')
    dict['qq'] = input('请输入QQ：')
    dict['mail'] = input('请输入邮箱：')
    print('...正在修改，请等待...')
    turnTime()
    print('修改成功，返回主界面')


def turnTime(): # 实现倒计时功能
    for i in list(range(5, 0, -1)):
        print(i, 's')
        time.sleep(1) # 睡眠一秒