#sum_min_max.py


# 输入三个数，存于列表中

a = int(input('请输入第一个数:'))

b = int(input('请输入第二个数:'))

c = int(input('请输入第三个数:'))

L=[a,b,c]

print('最大值是：',max(L))


print('最小值是：',min(L))


print('平均数是:',sum(L)/3)