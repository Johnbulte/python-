#super.py
#super(type,obj) 返回绑定超类的实例(要求obj必须为type类型的实例)
#super()  返回绑定的超类的实例，等同于 super(__class__,实例方法的第一个参数)，必须用在方法内调用
#此示例用super构造函数来间接调用父类的覆盖版本的方法
class A:
    def work(self):
        print('A.work()')
class B(A):
    def work(self):
        print('B.work()')
    def super_work(self):
        '''调用自己的work'''
        self.work()
        super(B,self).work()  #调用的父类work
b = B()
#b.work()   #B.work
#super(B,b).work()   #A.work
b.super_work()
