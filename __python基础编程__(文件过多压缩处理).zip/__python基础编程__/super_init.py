#super_init.py
class Human:
    def __init__(self,n,a):
        self.name = n
        self.age = a
    def infos(self):
        print('姓名：',self.name)
        print('年龄:',self.age)

class Student(Human):
    def __init__(self,n,a,s):
        super().__init__(n,a)
        '''------------第一种
        #self.name = n
        #self.age  = a-------方法-------'''
        self.score = s
        print('Student.__init__被调用')
    def infos(self):
        super().infos()
        print('成绩:',self.score)
h1 =Human('小张',18)
h1.infos()
s1 = Student('老魏',35,60)  #默认不调用父类
s1.infos()
'''class ClassName(object):
    """docstring for ."""
    def __init__(self, arg):
        #super(, self).__init__()
        self.arg = arg'''
