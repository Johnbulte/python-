#sushu.py
n = int(input('请输入一个数：'))
for x in range(2,n):
	if n % x == 0:
		print(n,'不是素数')
		break
else:
	print(n,'是素数')