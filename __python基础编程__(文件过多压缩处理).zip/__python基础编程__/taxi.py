#taxi.py
km=int(input('输入公里数:'))

if 0<km<=3:
    print('收费13元')
elif 3<km<=15:
    pay=13+(km-3)*2.3
    print('收费',round(pay),'元')
elif km>15:
    pay=(km-15)*3.45+(15-3)*2.3+13
    print('收费',round(pay),'元')
