from socket import *
#创建套接字 tcp
sockfd = socket()
#发起连接请求
sockfd.connect(('127.0.0.1',8888))
data = input('发送>>>>>>')
#发送消息
sockfd.send(data.encode())
data = sockfd.recv(1024).decode()
print(data)
#关闭套接字
sockfd.close()
