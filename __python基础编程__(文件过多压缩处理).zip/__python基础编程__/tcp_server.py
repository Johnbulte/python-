from socket import *
#创建套接字
sockfd = socket(AF_INET,SOCK_STREAM)
#绑定ip和端口
sockfd.bind(('127.0.0.1',8888))
#设置监听
sockfd.listen(5)
#等待客户端连接
print('waiting for connect....')
connfd,addr = sockfd.accept()
print('connect from',addr)
data = connfd.recv(1024)
print('receive message >>',data)
#发送
n = connfd.send('receive your message\n')
print('send %d bytes data'%n)
#关闭套接字
connfd.close()
sockfd.close()
