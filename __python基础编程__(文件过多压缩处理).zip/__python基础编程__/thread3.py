
# coding: utf-8

# In[4]:


#~123


# In[3]:


#12&8


# In[6]:


#daemon属性
from threading import Thread
from time import sleep
def fun():
    sleep(3)
    print('daemon 测试') #分支线程
t = Thread(target = fun)
t.setDaemon(True)
print(t.isDaemon())  #查看daemon属性
t.start()
print('=============main over============')#主线程

