#type_1_9.py

t = []#创建空元组，用于保存数据
for i in range(1,10):
	v=i**2
	t += (v,)
print(t)