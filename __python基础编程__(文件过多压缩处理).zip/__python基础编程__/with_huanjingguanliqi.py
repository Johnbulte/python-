#with_huanjingguanliqi.py
'''此示例示意环境管理器类的定义使用'''
class A:
    '''此类的对象可以用于with语句进行管理'''
    def __enter__(self):
        print('已经进入的with语句')
        return self
    def __exit__(self,exc_type,exc_value,exc_tb):
        print('已经离开了with语句')
        if exc_type is None:
            print('此程序正常离开')
        else:
            print('离开with语句出现异常\n异常类型是',exc_type,'\n','错误值是',exc_value)
try:
    with A() as a:
        print('这里是with语句里打印的')
        3/0
except:
    print('有异常发生，程序已转为正常')
print('程序退出')
