#with_test.py
'''此示例示意with语句的用法'''
src_file = input('请输入源文件:')
try:
    src = open(src_file,'rb')
    try:
        try:
        #准备打开另一个文件
            dst_file = input('请输入目标文件:')
            with open(dst_file,'wb') as dst:
                '''with函数的调用'''
                b = src.read()
                dst.write(b)
        except OSError:
            print('打开文件失败！')
    finally:
        src.close()
except OSError:
    print('打开文件',src_file,'失败')
