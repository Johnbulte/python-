#with_test.py
'''此示例示意with语句的用法'''
src_file = input('请输入源文件:')
dst_file = input('请输入目标文件:')
try:
    with open(src_file.'rb') as src,open(dst_file,'wb'):
        b =src.read()
        dst.write(b)
except OSError:
    print('复制失败')
