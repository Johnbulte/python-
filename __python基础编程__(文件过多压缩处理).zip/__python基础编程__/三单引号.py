#ls
 s= "I'm" 'a programer.'
  'my name is "zhangxiaoming"' 
 print(s)