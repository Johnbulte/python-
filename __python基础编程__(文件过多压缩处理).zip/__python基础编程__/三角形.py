#三角形.py
n = int(input('请输入三角宽度:'))
line = 1
while line <= n:
	print('*'*line)
	line += 1