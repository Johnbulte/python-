#三角形2.py
n = int(input('请输入三角形行数:'))
stars = n
while  stars > 0:
	print('*' * stars)
	stars-=1