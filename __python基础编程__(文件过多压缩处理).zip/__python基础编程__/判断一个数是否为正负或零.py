#问题：
#请输入一个数，判断这个数是正，负数，零？
n=int(input('请输入一个整数：'))
if n >0:
	print('这个数是正数')
elif n==0:
	print('这个数等于０')
else:
	print('这个数是负数')
