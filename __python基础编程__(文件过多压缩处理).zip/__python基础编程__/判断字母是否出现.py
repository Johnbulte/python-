#panduan.py
name=input('请输入您的名字：')
if 'hello' in name:
	print('您的名字出现啦！')
else:
	print('别瞎写')
