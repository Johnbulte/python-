#占位符练习.py
s1=input('请输入第一个字符串：')
s2=input('请输入第二个字符串：')
s3=input('请输入第三个字符串：')
print('%20s' %s1)
print('%20s' %s2)
print('%20s' %s3)

