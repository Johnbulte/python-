#去空格.py
k=input('请输入一个数值：')
print('您输入的字符串是：',k.strip(' '))
ls=k.strip(' ')
print('字符串的长度是：',len(ls))