#反射.py
class Dog(object):
    def __init__(self,name):
        self.name = name
    def eat(self):
        print('%s is eating...' % self.name)
d = Dog('NihanYang')
choice = input('>>:').strip()
#if choice == 'eat':
    #d.eat()//错误
print(hasattr(d,choice))
getattr(d,choice)()
