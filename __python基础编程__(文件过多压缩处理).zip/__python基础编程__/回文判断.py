#判断是不是中心对称
dc=input('请输入字符串：')
dc2=dc[::-1]
if dc==dc2:
	print('这个字符串是回文')
else:
	print('这个字符串不是回文')