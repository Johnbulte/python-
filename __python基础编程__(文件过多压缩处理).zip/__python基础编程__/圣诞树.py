#圣诞树.py
h = int(input('请输入树干高度:'))
for x in range(1,h):
	print('*'*(x*2-1))
	x +=1
else:
	print('*'*h*2)