print('        *')
print('       ***')
print('     ******')
print('   **********')