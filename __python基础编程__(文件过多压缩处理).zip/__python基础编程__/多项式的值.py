#多项式的和.py
n = int(input('请输入一个数:'))
sn=0
i=0
while i<=n:
	sn += 1/2**i
	i+=1
print(sn)