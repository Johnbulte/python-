#字符串的打印处理
str1=input('请输入一个字符串：')
str2=str1[1:-1]
print('这个字符串为：',str2)

