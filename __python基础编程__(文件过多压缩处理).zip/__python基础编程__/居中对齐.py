#居中对齐.py
str1=input('请输入第一个字符串：')

str2=input('请输入第二个字符串：')

str3=input('请输入第三个字符串：')

x=int(input('请输入空格数：'))

length = (len(str1),len(str2),len(str3))

print('+' + '-' * (max(length)+ x) +'+')

print('|'+str1.center(max(length)+x)+'|')

print('|'+str2.center(max(length)+x)+'|')

print('|'+str3.center(max(length)+x)+'|')
print('+'+'-'* (max(length)+x)+'+')

