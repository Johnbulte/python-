#usr/bin/python
#循环求和语句
s,i=0,0
while i < 100:
	i+=1
	s+=i
print(s)