#循环语句的练习.py
begin=int(input('请输入开始值：'))
end=int(input('请输入结束值：'))
i = begin
while i < end :
	print(i,end=' ')
	i += 1
else:
	print()