#思考能否以最长字符串进行右对齐显示？.py
s1=input('请输入第一个字符串：')
s2=input('请输入第二个字符串：')
s3=input('请输入第三个字符串：')
length=len(s1)
if len(s2)>length:
	length=len(s2)
if len(s3)>length:
	length=len(s3)
#生成一个字符串
fmt='%'+str(length) + 's'
print(fmt % s1)
print(fmt % s2)
print(fmt % s3)