#!usr/bin/python
n=int(input('输入一个整数：'))
line=1#line代表当前的行数
while line <= n:
	#print('----------')
	i=1
	while i <= n:
		print(i,end=' ')
		i+=1
	print()
	line+=1