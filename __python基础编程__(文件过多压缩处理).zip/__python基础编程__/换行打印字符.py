#python3.py
print('i love fish.com\n'*3600)