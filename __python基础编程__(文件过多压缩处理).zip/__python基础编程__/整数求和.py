#!输入整数
m=int(input('请输入一个整数:'))
i = 0
cnt=0.0
while i <m+1:
	cnt += 1/(2**i)
	i+=1
print('相加的和为：',cnt)