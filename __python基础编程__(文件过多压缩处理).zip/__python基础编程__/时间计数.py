
time=63320
hour=time//3600
minute=(63320-hour*3600)//60
secend=63320%60
print('现在是%d时%d分%d秒'%(hour,minute,secend))
print(hour,'时',minute,'分',secend,'秒')