#输入一个开始的浮点数用begin绑定，输入一个结束的浮点数用end表示，输入每个数的间隔用step来绑定：
#打印出来：
begin=float(input('请输入开始浮点数:'))
end=float(input('请输入结束浮点数:'))
step=int(input('请输入步长:'))
_begin=int(begin)
_end=int(end)
print(_begin,' ',_end)
while _begin <= _end - step:
	print(_begin,end=" ")
	_begin+=step
print()