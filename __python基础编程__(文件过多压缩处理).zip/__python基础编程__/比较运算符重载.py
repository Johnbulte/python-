#比较运算符重载.py
class Mylist:
    def __init__(self,iterable=()):
        self.data = [x for x in iterable]
    def __repr__(self):
        return 'Mylist(%r)'%self.data
    def __gt__(self,rhs):
        if self.data[0] > rhs.data[0]:
            return True
        return False
L1 = Mylist(range(3,4))
L2 = Mylist(range(4,7))
print(L1,'>',L2,'=',L1 > L2)
print(L1,'<',L2,'=',L1 < L2)
