#求100以内求于.py

for num in range(101):
	if num * (num+1) % 11 == 8:
		print(num)