#猜拳游戏.py
import random
#提示用户并获取一个数字

player = int(input('请选择　剪刀0 石头1 布2:'))

# 让电脑随机产生一个数值，每次运行都不同

#random工具箱

computer = random.randint(0,2)

#判断输赢，并显示相应的结果


if (player== 0 and computer == 2 ) or (player == 1 and computer == 0 ) or (player == 2 and computer == 1 ):
	print('赢了，走，去喝一杯')
elif player == computer:
	print('平局，不要走，决战到天亮')
else:
	print('输了洗洗手再来！')