#!/usr/bin/python3
#用while打印10+1的整数.py
i=10
while i >= 1:
	print(i,end=' ')
	i=i-1
	print()
