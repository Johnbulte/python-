#help.py
#设置一个变量（这个变量为passwd)
Name=1
passwd=123456
login=int(input('请输入用户名：'))
if Name==login:
	print('用户１已登录')
else:
	print('用户未找到')
pass
pwd=int(input('请输入密码：'))
if pwd==passwd:
	print('密码正确')
else:
	print('密码错误')
