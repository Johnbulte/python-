#练习题１(len).py
num=input('请输入一个字符串：')
print('第一个字符是：',num[0])
pass
print('最后一个字符是：',num[-1])
s=len(num)//2
if len(num) % 2 > 0:
	print('中间的是：',num[s])


