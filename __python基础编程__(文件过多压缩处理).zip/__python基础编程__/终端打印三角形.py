#输入一个字符*，使用字符串控制他的空格数.py
kongge=int(input('请输入变量：'))
print(' '*kongge +'*')
print(' '*(kongge-1) +'***')
print(' '*(kongge-2) +'*****')
