#绝对值.py
n=int(input('请输入一个数：'))
m=n if n > 0 else -n
print('这个数的绝对值是：',m)