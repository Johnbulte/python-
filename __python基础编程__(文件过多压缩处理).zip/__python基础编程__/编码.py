#编码.py
str1=input('请输入一个字符串：')
if str1!="":
	print('这个字符串的第一个字母是：',ord(str1[0]))
else:
	print('输入错误！')