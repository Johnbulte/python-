#编码2.py
sup=int(input('请输入一个整数：'))
if 0<=sup<=65535:
	print('这个字符串的编码是：',chr(sup))
else:
	print('输入错误(0-65535)')
