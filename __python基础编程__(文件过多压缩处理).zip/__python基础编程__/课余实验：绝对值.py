#jython.py
#课余实验
py=int(input('请输入一个数：'))
if py<0:
	 py = -py
print('绝对值是：',py)