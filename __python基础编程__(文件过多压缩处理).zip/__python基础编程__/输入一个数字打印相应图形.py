#list
w=int(input('请输入矩形的宽度：'))
h=int(input('请输入矩形的高度：'))
print("#"*w)
print("#"+" "*(w-2)+"#")*h
print("#"+" "*(w-2)+"#")*h
print("#"*w)
