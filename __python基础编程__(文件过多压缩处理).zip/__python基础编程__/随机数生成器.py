#random.py
from random import *
s = print(randint(1,43))
print(s)

